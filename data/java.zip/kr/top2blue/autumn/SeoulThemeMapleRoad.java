package kr.top2blue.autumn;

import java.util.List;

import lombok.Data;

@Data
public class SeoulThemeMapleRoad {
	private String themeTitle;
	private String themeComment;
	private List<MapleRoad> themeList;
	@Data
	public static class MapleRoad{
		String map;
		String imageUrl;
		String title;
		String tree;
		String length;
		String contact;
		String subject;
	}
}
