package kr.top2blue.autumn;

import lombok.Data;

@Data
public class Seoul {
	private int index;
	private String name;
	private String image;
	private String homepage;
}
