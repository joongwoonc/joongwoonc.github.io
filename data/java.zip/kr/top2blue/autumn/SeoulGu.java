package kr.top2blue.autumn;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class SeoulGu {
	public static void main(String[] args) {
		String baseUrl = "https://data.seoul.go.kr";
		String url = baseUrl + "/link/districtList.do";
		
		List<Seoul> seoulGuList = new ArrayList<>();
		try {
			Document doc = Jsoup.connect(url).get();
			Elements guList = doc.select("div.list-gu ul li");
			System.out.println("자치구 개수 : " + guList.size());
			int index = 0;
			for(Element gu : guList) {
				String homepage = gu.selectFirst("a").attr("href");
				String name = gu.selectFirst("img").attr("alt");
				String image = baseUrl + gu.selectFirst("img").attr("src");
			
				System.out.println(homepage);
				System.out.println(name);
				System.out.println(image);
				ImageDownload.download(image, "logo/seoul");
				System.out.println("-".repeat(100));
				
				Seoul seoul = new Seoul();
				seoul.setIndex(++index);
				seoul.setHomepage(homepage.replace("data.", "www."));
				seoul.setImage(image);
				seoul.setName(name);
				
				seoulGuList.add(seoul);
			}
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			PrintWriter pw = new PrintWriter("src/main/resources/SeoulGu.json");
			gson.toJson(seoulGuList, pw);
			pw.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
