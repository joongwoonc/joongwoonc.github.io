package kr.top2blue.autumn;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GyeonggiSi {
	public static void main(String[] args) {
		String baseUrl = "https://www.gg.go.kr/";
		String url = baseUrl + "/contents/contents.do?ciIdx=458&menuId=1809";
		List<Gyeonggi> gyeonggiSiList = new ArrayList<>();
		int index = 0;
		try {
			Document doc = Jsoup.connect(url).get();
			Elements siList = doc.select("form#form>div#result>div>div");
			System.out.println(siList.size());
			for(Element si : siList) {
				Elements es = si.select("a");
				for(Element a : es) {
					if(a.attr("href")!=null && !a.attr("href").equals("")) {
						Gyeonggi gyeonggi = new Gyeonggi();
						gyeonggi.setIndex(++index);
						String homepage = a.attr("href");
						homepage = homepage.substring(0, homepage.indexOf(".kr")+3);
						System.out.println(homepage);
						gyeonggi.setHomepage(homepage);
						
						String name = a.selectFirst("h5>strong").text();
						System.out.println(name);
						gyeonggi.setName(name);
						
						String image = baseUrl + a.selectFirst("img").attr("src");
						System.out.println(image);
						gyeonggi.setImage(image);
						ImageDownload.download(image, "logo/gyeonggi");
						
						gyeonggiSiList.add(gyeonggi);
					}
					
				}
			}
			System.out.println(gyeonggiSiList.size() + "개!!!!");
			
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			PrintWriter pw = new PrintWriter("src/main/resources/GyeonggiSi.json");
			gson.toJson(gyeonggiSiList, pw);
			pw.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
