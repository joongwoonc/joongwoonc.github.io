package kr.top2blue.autumn;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class SeoulAutumn {
	public static void main(String[] args) {
		Map<String, String> map = new HashMap<>();
		map.put("t1", "가로,ico-visit3.png");
		map.put("t2", "가로녹지,ico-visit6.png");
		map.put("t3", "가로임야,ico-visit5.png");
		map.put("t4", "공원,ico-visit1.png");
		map.put("t5", "등산로,ico-visit4.png");
		map.put("t6", "하천변,ico-visit2.png");
		String baseURL = "https://www.seoul.go.kr";
		List<SeoulMapleRoad> mapleRoadList = new ArrayList<>();
		try {
			Document doc = Jsoup.connect("https://www.seoul.go.kr/storyw/autumn/list.do").get();
			// 서울 단풍길 103선
			Elements elements = doc.select("div#visitlist div.box");
			System.out.println("서울 단풍길 103선");
			System.out.println(elements.size() + "개");
			System.out.println("=".repeat(50));
			for(Element e : elements) {
				SeoulMapleRoad seoulMapleRoad = new SeoulMapleRoad();
				String icon = e.attr("class").split(" ")[1];
				String category = map.get(icon).split(",")[0];
				String categoryImageUrl = baseURL + String.format("/res_newseoul_story/autumn/images/ico/%s", map.get(icon).split(",")[1]);
				System.out.println(category);
				System.out.println(categoryImageUrl);
				
				seoulMapleRoad.setCategory(category);
				seoulMapleRoad.setCategoryImageUrl(categoryImageUrl);
				
				String local = e.select("p.local").get(0).text();
				System.out.println(local);
				
				seoulMapleRoad.setLocal(local);
				
				String title = e.select("h3").get(0).text();
				String subTitle = e.select("h3 span").get(0).text();
				title = title.substring(0, title.indexOf(subTitle));
				System.out.println(title);
				System.out.println(subTitle);
				
				seoulMapleRoad.setTitle(title);
				seoulMapleRoad.setSubTitle(subTitle);
				
				String mapAddress = e.select("address a").get(0).attr("onclick");
				// System.out.println(mapAddress);
				int start = mapAddress.indexOf("'")+1;
				int end = mapAddress.lastIndexOf("'");
				mapAddress = mapAddress.substring(start, end);
				System.out.println(mapAddress);
				
				seoulMapleRoad.setMapAddress(mapAddress);

				String tree = e.select("div.content dl dd").get(0).text();
				String length = e.select("div.content dl dd").get(1).text();
				System.out.println(String.format("수종 : %s, 길이 : %s", tree, length));
				
				seoulMapleRoad.setTree(tree);
				seoulMapleRoad.setLength(length);
				
				String comment = e.select("div.content p").get(0).text();
				String contact = comment.substring(comment.indexOf("문의 : "));
				comment = comment.substring(0, comment.indexOf("문의 : "));
				System.out.println(comment);
				System.out.println(contact);
				
				seoulMapleRoad.setComment(comment);
				seoulMapleRoad.setContact(contact);
				
				String imageUrl = baseURL + e.select("div.cnt-pic img").get(0).attr("src");
				System.out.println(imageUrl);
				
				seoulMapleRoad.setImageUrl(imageUrl);
				System.out.println("-".repeat(50));
				
				mapleRoadList.add(seoulMapleRoad);
			}
			
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			PrintWriter pw = new PrintWriter("src/main/resources/SeoulMapleRoadList.json");
			gson.toJson(mapleRoadList, pw);
			pw.close();
			
			System.out.println(mapleRoadList.size() + "개 저장 완료!!!!");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
