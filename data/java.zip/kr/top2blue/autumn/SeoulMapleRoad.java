package kr.top2blue.autumn;

import lombok.Data;

@Data
public class SeoulMapleRoad {
	String category;
	String categoryImageUrl;
	String local;
	String title;
	String subTitle;
	String mapAddress;
	String tree;
	String length;
	String comment;
	String contact;
	String imageUrl;
}
