package kr.top2blue.autumn;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class SeoulAutumn2 {
	public static void main(String[] args) {
		// 테마별로 보는 단풍길(/story/autumn/img/txt-theme.png)
		String baseURL = "https://www.seoul.go.kr";
		String url = baseURL + "/story/autumn/pc.html";
		// /story/autumn/img/bg-tab-menu.png
		
		List<SeoulThemeMapleRoad> themeMapleRoadList = new ArrayList<>();
		
		try {
			Document doc = Jsoup.connect(url).get();

			Elements elements = doc.select("div.ctUL-wrap");
			for (Element e : elements) {
				SeoulThemeMapleRoad themeMapleRoad = new SeoulThemeMapleRoad(); 
				
				String title = e.select("p.thema-sub-tit span").text();
				String comment = e.select("p.thema-sub-tit").text();
				comment = comment.substring(title.length()).trim();
				System.out.println(title);
				System.out.println(comment);
				themeMapleRoad.setThemeTitle(title);
				themeMapleRoad.setThemeComment(comment);
				System.out.println("-".repeat(130));
				
				Elements list = e.select("ul.ctUL li");
				System.out.println(list.size() + "개 있음");
				
				List<SeoulThemeMapleRoad.MapleRoad>  mapleRoadList = new ArrayList<>();
				
				for(Element item : list) {
					if(item.selectFirst(".info-wrap")!=null) {
						SeoulThemeMapleRoad.MapleRoad mapleRoad = new SeoulThemeMapleRoad.MapleRoad();
						
						String map = item.select("a").attr("href");
						System.out.println(map);
						mapleRoad.setMap(map);
						
						String imageUrl = baseURL + "/story/autumn/" + item.selectFirst("a img").attr("src");
						System.out.println(imageUrl);
						mapleRoad.setImageUrl(imageUrl);
						
						String infoTitle = item.selectFirst("div.red-tit").text();
						System.out.println(infoTitle);
						mapleRoad.setTitle(infoTitle);
						
						String infoName = item.selectFirst("div.info span.name").text();
						System.out.println(infoName);
						mapleRoad.setTree(infoName);
						
						if(item.selectFirst("div.info span.space")!=null) {
							String infoSpace = item.selectFirst("div.info span.space").text();
							System.out.println(infoSpace);
							mapleRoad.setLength(infoSpace);
						}else {
							mapleRoad.setLength("");
						}
						
						String infoTel = item.selectFirst("div.info span.tel").text();
						System.out.println(infoTel);
						mapleRoad.setContact(infoTel);
						
						String infoSubject = item.selectFirst("div.subject").text();
						System.out.println(infoSubject);
						mapleRoad.setSubject(infoSubject);
						
						mapleRoadList.add(mapleRoad);
						System.out.println("-".repeat(130));
					}
					
				}
				themeMapleRoad.setThemeList(mapleRoadList);
				System.out.println(themeMapleRoad);
				themeMapleRoadList.add(themeMapleRoad);
				System.out.println("=".repeat(130));
			}
			System.out.println(themeMapleRoadList);
			
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			PrintWriter pw = new PrintWriter("src/main/resources/SeoulThemeMapleRoadList.json");
			gson.toJson(themeMapleRoadList, pw);
			pw.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
