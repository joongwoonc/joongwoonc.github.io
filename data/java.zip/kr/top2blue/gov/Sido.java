package kr.top2blue.gov;

import java.util.List;

import lombok.Data;

@Data
public class Sido {
	private String code; 
	private String name;
	private String link;
	private List<LocalSi> list;
	
	@Data
	public static class LocalSi{
		private String code; 
		private String name;	
		private String link;	
	}
}
