package kr.top2blue.gov;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Stream;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

public class GovDong2 {
	public static void main(String[] args) {
		// 지방 지자체까지 읽고
		List<String> list = null;
		try {
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			FileReader fr = new FileReader("src/main/resources/sido.json");
			List<Sido> sidoLists = gson.fromJson(fr, new TypeToken<List<Sido>>() {}.getType());
			fr.close();
			System.out.println(sidoLists);
			
			// 전체를 리스트로 읽고
			list = Files.readAllLines(Paths.get("src/main/resources/dong.txt")); 
			// 폐지를 걸러서
			Stream<String> stream = list.stream();
			list = stream.filter(data->data.contains("존재")).toList(); 
			
			
			for(Sido sido : sidoLists) {
				stream = list.stream();
				List<String> list2 = stream.filter((data)->{
					String t[] = data.split("\t");
					return t[0].startsWith(sido.getCode().substring(0,2)) && t[0].endsWith("00000") && !t[0].equals(sido.getCode());
				}).toList();
				Set<String> set = new TreeSet<String>(list2);
				System.out.println(sido.getName() + " : " + set.size() + "개구");
				List<Sido.LocalSi> sidoList = new ArrayList<Sido.LocalSi>();
				for(String t : set) {
					String[] data = t.split("\t");
					if(data[1].split(" ").length==2) {
						Sido.LocalSi si = new Sido.LocalSi();
						String code = data[0];
						String name = data[1];
						System.out.println(code + " : " + name);
						si.setCode(code);
						si.setName(name);
						sidoList.add(si);
					}
				}
				sido.setList(sidoList);
			}
			System.out.println(sidoLists);
			sidoLists.sort(new Comparator<Sido>() {

				@Override
				public int compare(Sido o1, Sido o2) {
					return o1.getName().compareTo(o2.getName());
				}
				
			});
			
			PrintWriter pw = new PrintWriter("src/main/resources/sidoList.json");
			gson.toJson(sidoLists, pw);
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
