package kr.top2blue.gov;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

public class GovDong3 {
	public static void main(String[] args) {
		// 두개를 읽어 링크자료만 복사해서 넣어준다.
		try {
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			FileReader fr = new FileReader("src/main/resources/sidoList.json");
			List<Sido> sidoLists = gson.fromJson(fr, new TypeToken<List<Sido>>() {}.getType());
			fr.close();
			System.out.println(sidoLists);

			FileReader fr2 = new FileReader("src/main/resources/Government.json");
			List<GovernmentVO> governments = gson.fromJson(fr2, new TypeToken<List<GovernmentVO>>() {}.getType());
			fr2.close();
			System.out.println(governments);

			for(int i=0;i<sidoLists.size();i++) {
				Sido sido = sidoLists.get(i);
				GovernmentVO gov = governments.get(i);
				sido.setLink(gov.getLink());
				
				List<Sido.LocalSi> list1 = sido.getList();
				List<GovernmentVO.LocalGovernment> list2 = gov.getList();
				
				if(list2!=null) {
					list1.sort(new Comparator<Sido.LocalSi>() {
						@Override
						public int compare(Sido.LocalSi o1, Sido.LocalSi o2) {
							return o1.getName().compareTo(o2.getName());
						}
					});
					list2.sort(new Comparator<GovernmentVO.LocalGovernment>() {
						@Override
						public int compare(GovernmentVO.LocalGovernment o1, GovernmentVO.LocalGovernment o2) {
							return o1.getName().compareTo(o2.getName());
						}
					});
					System.out.println(list1.size() + " : " +  list2.size());
					for(int j=0;j<list1.size();j++) {
						Sido.LocalSi si = list1.get(j);
						GovernmentVO.LocalGovernment go = list2.get(j);
						// System.out.println(si);
						// System.out.println(go);
						si.setName(go.getName());
						si.setLink(go.getLink());
					}
				}
			}
			// 지자체 정렬
			for(Sido sido : sidoLists) {
				sido.getList().sort((o1, o2)->{
					return o1.getCode().compareTo(o2.getCode());
				});
			}
			
			// 광역시도 코드로 정렬
			sidoLists.sort(new Comparator<Sido>() {
				@Override
				public int compare(Sido o1, Sido o2) {
					return o1.getCode().compareTo(o2.getCode());
				}
			});
			
			for(Sido sido : sidoLists) {
				System.out.println(sido);
			}
			

			PrintWriter pw = new PrintWriter("src/main/resources/sidoLists.json");
			gson.toJson(sidoLists, pw);
			pw.close();
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
