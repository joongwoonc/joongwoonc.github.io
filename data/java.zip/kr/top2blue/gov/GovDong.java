package kr.top2blue.gov;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class GovDong {
	public static void main(String[] args) {
		// 광역 지자체만 읽기
		List<String> list = null;
		try {
			// 전체를 리스트로 읽고
			list = Files.readAllLines(Paths.get("src/main/resources/dong.txt")); 
			// System.out.println(list.size() + "개");
			
			// 폐지를 걸러서
			Stream<String> stream = list.stream();
			list = stream.filter(data->data.contains("존재")).toList(); 
			// System.out.println(list.size() + "개");
			
			// 광역자치 단체만
			stream = list.stream();
			System.out.println(list.get(0).split("\t")[0]);
			List<String> list2 = stream.filter(data->data.split("\t")[0].endsWith("00000000") || data.split("\t")[0].equals("3611000000")).toList();
			
			System.out.println(list2.size() + "개");
			List<Sido> sidoList = new ArrayList<Sido>();
			for(String t : list2) {
				String[] data = t.split("\t");
				String code = data[0];
				String name = data[1];
				Sido sido = new Sido();
				sido.setCode(code);
				sido.setName(name);
				System.out.println(sido);
				sidoList.add(sido);
			}
			PrintWriter pw = new PrintWriter("src/main/resources/sido.json");
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			gson.toJson(sidoList, pw);
			pw.close();
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
