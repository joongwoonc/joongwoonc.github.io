package kr.top2blue.gov;

import java.util.List;

import lombok.Data;

@Data
public class GovernmentVO {
	private int code;
	private String name;
	private String link;
	private List<LocalGovernment> list;
	
	@Data
	public static class LocalGovernment{
		private int code;
		private String name;
		private String link;
	}
}
