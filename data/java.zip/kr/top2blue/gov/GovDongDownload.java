package kr.top2blue.gov;

import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import kr.top2blue.autumn.ImageDownload;

public class GovDongDownload {
	public static void main(String[] args) {
		// 전국 지자체별 로고 다운로드하기
		try {
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			FileReader fr = new FileReader("src/main/resources/sidoList.json");
			List<Sido> sidoLists = gson.fromJson(fr, new TypeToken<List<Sido>>() {}.getType());
			fr.close();
			System.out.println(sidoLists);
			
			for(Sido sido : sidoLists) {
				String imageName = "https://www.laiis.go.kr/images/egovframework/img_logo_" + sido.getCode() + ".png";
				ImageDownload.download(imageName, "sido");
				
				if(sido.getList()!=null && sido.getList().size()>0) {
					for(Sido.LocalSi si : sido.getList()) {
						imageName = "https://www.laiis.go.kr/images/egovframework/img_logo_" + si.getCode() + ".png";
						ImageDownload.download(imageName, "sido");
					}
				}
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
