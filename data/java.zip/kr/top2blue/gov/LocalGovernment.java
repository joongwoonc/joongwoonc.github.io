package kr.top2blue.gov;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class LocalGovernment {
	public static void main(String[] args) {
		// 전국 지자체 홈페이지 정보 얻기
		String url = "https://www.mois.go.kr/frt/sub/a04/localGovernment/screen.do";
		List<GovernmentVO> list = new ArrayList<GovernmentVO>();
		try {
			Document doc = Jsoup.connect(url).get();
			Elements elements1 = doc.select("#print_area>h3>a");
			Elements elements2 = doc.select("#print_area>ul");
			System.out.println(elements1.size() + " : " + elements2.size());
			int j = 0;
			for(int i=0;i<elements1.size();i++) {
				GovernmentVO gov = new GovernmentVO();
				Element e1 = elements1.get(i);
				String name = e1.text();
				String link = e1.attr("href");
				// System.out.println(name + " : " + link);
				
				gov.setName(name);
				gov.setLink(link);
				
				if(name.equals("세종특별자치시")) { // 세종특별자치시는 밑에 지자체 없다.
					gov.setList(null);
				}else {
					Elements elements3 = elements2.get(j).select("li");
					List<GovernmentVO.LocalGovernment> localList = new ArrayList<GovernmentVO.LocalGovernment>();
					for(Element e : elements3) {
						GovernmentVO.LocalGovernment localGov = new GovernmentVO.LocalGovernment();
						String localName = e.selectFirst("a").text(); 
						String localLink = e.selectFirst("a").attr("href"); 
						// System.out.println(localName + " : " + localLink);
						
						localGov.setName(localName);
						localGov.setLink(localLink);
						
						localList.add(localGov);
						// System.out.println("-".repeat(100));
						
					}
					j++;
					// System.out.println("=".repeat(100));
					gov.setList(localList);
				}
				list.add(gov);
			}
			
			System.out.println(list);
			
			list.sort(new Comparator<GovernmentVO>() {
				@Override
				public int compare(GovernmentVO o1, GovernmentVO o2) {
					return o1.getName().compareTo(o2.getName());
				}
			});
			
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			PrintWriter pw = new PrintWriter("src/main/resources/Government.json");
			gson.toJson(list, pw);
			pw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
